import React from "react";
import HotelSupportDashboard from "./HotelSupportDashboard";

export default function App() {
  return <HotelSupportDashboard />;
}
