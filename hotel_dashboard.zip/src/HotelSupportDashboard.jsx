import React, { useState } from "react";

export default function HotelSupportDashboard() {
  const initialComplaints = [
    {
      id: "C-1001",
      customer: "Ahmed Ali",
      phone: "+971501234567",
      bookingId: "BKG-7890",
      hotel: "Palm Hotel",
      status: "New",
      message:
        "I arrived and the room was not available even though I booked 2 nights.",
      createdAt: "2025-11-10",
    },
    {
      id: "C-1002",
      customer: "Laila Noor",
      phone: "+971509876543",
      bookingId: "BKG-7901",
      hotel: "Sea Resort",
      status: "In Progress",
      message: "I want to change my booking date to next week.",
      createdAt: "2025-11-11",
    },
  ];

  const hotels = [
    { id: "H-001", name: "Palm Hotel", availableRooms: 0, price: 80 },
    { id: "H-002", name: "Oasis Hotel", availableRooms: 3, price: 95 },
    { id: "H-003", name: "Sea Resort", availableRooms: 2, price: 120 },
    { id: "H-004", name: "Guest House", availableRooms: 5, price: 60 },
  ];

  const [complaints, setComplaints] = useState(initialComplaints);
  const [selected, setSelected] = useState(null);
  const [conversation, setConversation] = useState([]);
  const [isSimulating, setIsSimulating] = useState(false);

  function openComplaint(c) {
    setSelected(c);
    setConversation([]);
  }

  async function virtualAgentReply(text) {
    await new Promise((r) => setTimeout(r, 700));
    const available = hotels.filter((h) => h.availableRooms > 0);
    if (text.includes("not available") || text.includes("room")) {
      return {
        text: `Sorry for the inconvenience. Alternative hotels available: ${available
          .map((a) => a.name)
          .join(", ")}. Would you like to move your booking?`,
      };
    }
    if (text.includes("change")) {
      return { text: "Sure, what new date would you like?" };
    }
    return { text: "I understand. I can forward this issue to support if you want." };
  }

  async function simulateCall() {
    setIsSimulating(true);
    setConversation((c) => [
      ...c,
      { from: "agent", text: "Hello, I'm your virtual assistant. How can I help you today?" },
    ]);

    setTimeout(() => {
      const userMessage = {
        from: "user",
        text: selected ? selected.message : "I want to change my booking.",
      };
      setConversation((c) => [...c, userMessage]);
      virtualAgentReply(userMessage.text).then((reply) => {
        setConversation((c) => [...c, { from: "agent", text: reply.text }]);
      });
    }, 800);

    setTimeout(() => setIsSimulating(false), 2500);
  }

  function applyAlternative(hotel) {
    if (!selected) return;
    setComplaints((prev) =>
      prev.map((p) =>
        p.id === selected.id
          ? { ...p, hotel: hotel.name, status: "Moved" }
          : p
      )
    );
    setSelected((s) =>
      s ? { ...s, hotel: hotel.name, status: "Moved" } : s
    );
  }

  return (
    <div style={{ padding: 20, fontFamily: "sans-serif" }}>
      <h2>Hotel Booking Support Dashboard (Simulation)</h2>
      <p>This is a demo dashboard to test AI complaint handling.</p>

      <div style={{ display: "flex", gap: 20 }}>
        <div style={{ width: "30%", border: "1px solid #ddd", padding: 10, borderRadius: 10 }}>
          <h3>Complaints</h3>
          {complaints.map((c) => (
            <div
              key={c.id}
              onClick={() => openComplaint(c)}
              style={{
                padding: 10,
                marginBottom: 10,
                cursor: "pointer",
                background: selected && selected.id === c.id ? "#eef5ff" : "#f9f9f9",
                borderRadius: 8,
              }}
            >
              <strong>{c.customer}</strong>
              <br />
              <small>{c.bookingId} • {c.hotel}</small>
              <br />
              <small>Status: {c.status}</small>
            </div>
          ))}
        </div>

        <div style={{ width: "70%", border: "1px solid #ddd", padding: 10, borderRadius: 10 }}>
          {!selected ? (
            <p>Select a complaint to begin.</p>
          ) : (
            <>
              <h3>{selected.customer} • {selected.bookingId}</h3>
              <p>Phone: {selected.phone} • Hotel: {selected.hotel}</p>

              <button onClick={simulateCall} disabled={isSimulating}>
                {isSimulating ? "Simulating..." : "Simulate Call"}
              </button>

              <h4>Original Message</h4>
              <div style={{ background: "#f0f0f0", padding: 10, borderRadius: 8 }}>
                {selected.message}
              </div>

              <h4>Conversation</h4>
              <div style={{ height: 150, overflowY: "auto", border: "1px solid #ccc", padding: 10 }}>
                {conversation.map((m, i) => (
                  <div key={i} style={{ textAlign: m.from === "agent" ? "right" : "left" }}>
                    <span
                      style={{
                        background: m.from === "agent" ? "#e8f0ff" : "#eee",
                        padding: 8,
                        borderRadius: 6,
                        display: "inline-block",
                        marginBottom: 6,
                      }}
                    >
                      {m.text}
                    </span>
                  </div>
                ))}
              </div>

              <h4>Alternative Hotels</h4>
              {hotels.map((h) => (
                <div key={h.id} style={{ marginBottom: 10 }}>
                  <strong>{h.name}</strong> — Rooms: {h.availableRooms} — ${h.price}
                  <br />
                  <button onClick={() => applyAlternative(h)}>Move Booking</button>
                </div>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
